import './Favorites.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCircleXmark } from '@fortawesome/free-regular-svg-icons';
import Info from "../Info/Info";
import { faTrashCan } from '@fortawesome/free-regular-svg-icons';

export default function Favorites({displayFavorites, setDisplayFavorites, favoriteList, deleteFromFavoriteList}){

    return(
        <div className={` ${displayFavorites===true?"favoriteContainer":"notDisplay"}`}>
            <div className='favoriteHeader'>  <FontAwesomeIcon onClick={()=>setDisplayFavorites(!displayFavorites)} style={{ fontSize: '2.1rem', color: '#9f2913' }}  icon={faCircleXmark} />
            </div>
            <hr style={{color:"red"}}/>

            <div>
                {
                    favoriteList.length>0 ? favoriteList.map((character)=>{
                        return(
                            <div key={character.id} className="favoriteCharacterContainer">
                                <img src={character.image} className='imgFavorite' alt=""/>
                                <Info gender={character.gender} status={character.status} name={character.name} />
                                <FontAwesomeIcon onClick={()=>deleteFromFavoriteList(character.id)} className='favTrashIcon' icon={faTrashCan}   />
                            </div>
                        )
                    }) : <h2 className="favoriteText"> your favorite list is empty </h2>
                }
            </div>
        </div>
    )
}


