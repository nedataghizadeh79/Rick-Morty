import './Header.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart } from '@fortawesome/free-regular-svg-icons';


export default function Header({numberOfFavorites, setDisplayFavorites, displayFavorites, searchValue, setSearchValue, allCharacters}){

    function saveInputValue(e) {
        setSearchValue(e.target.value)
    }

    return(
        <div className='containerHeader'>
            <h2>Logo</h2>
            <input value={searchValue} onChange={saveInputValue} className='inputMain' placeholder="  Search..."/>
            <h4>Result= {allCharacters.length} Characters </h4>
            <div className='mainIcon'>
                <FontAwesomeIcon onClick={()=>setDisplayFavorites(!displayFavorites)} style={{fontSize:"2.4rem", color:'#9a2e18'}}  icon={faHeart} />
                <div onClick={()=>setDisplayFavorites(!displayFavorites)} className='numberOfFavorites'>{numberOfFavorites}</div>
            </div>
        </div>
    )
}
