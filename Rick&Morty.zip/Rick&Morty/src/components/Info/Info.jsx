import './Info.css'
export default function Info({gender, name, status }){
    return(
        <div>
            <div className='columnSide'>
                <h3 className='nameInfo'> {gender==="Male" ? "👱‍️":"👩"}  {name}</h3>
                <h5> {status==="Dead" ? "🔴": status==="Alive"?"🟢" : status==="unknown"?"🟠":"⚪" } {status}</h5>
            </div>
        </div>
    )
}
