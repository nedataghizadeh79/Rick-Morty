import './Main.css'
import Header from "../header/Header";
import CharacterCard from "../character card/CharacterCard";
import {useContext, useEffect, useState} from "react";
import Favorites from "../favorites/Favorites";
import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {FavoriteListContext} from '../../context/FavoriteListContext'

export default function Main(){
    const [displayFavorites, setDisplayFavorites] = useState(false)
    const[searchValue, setSearchValue] = useState("")
    const [searchedResultList, setSearchedResultList] = useState([])
    const [allCharacters, setAllCharacters] = useState([])
    const {favoriteList, setFavoriteList} = useContext(FavoriteListContext)

    useEffect(()=>{
        localStorage.setItem("allCharacters", JSON.stringify(allCharacters))
    },[allCharacters])

    useEffect(()=>{
        const allCharacters = JSON.parse(localStorage.getItem("allCharacters"))
        if(allCharacters){
            setAllCharacters(allCharacters)
        }
    },[])


    useEffect(()=>{
        const controller = new AbortController()
        axios.get('https://rickandmortyapi.com/api/character/[1,2,3,4,5,6,7,8,9]', {signal: controller.signal}).then((res)=>{
            const characters = res.data.slice(0,8)
            setAllCharacters(characters)
            if (searchValue !== ""){
                let searchedValue= characters.filter((character)=>character.name.toLowerCase().includes(searchValue.toLowerCase()))
                setSearchedResultList(searchedValue)
            }else {
                setSearchedResultList(characters)
            }
        }).catch((err)=>{
            if(axios.isCancel(err)){
                console.log("Request was canceled")
            }else {
                toast.error("Error fetching data")
            }
        })

        return ()=>{
            controller.abort();
        }

    },[searchValue])


    function deleteFromFavoriteList(id){
        setFavoriteList( favoriteList.filter((character)=> character.id!==id) )
    }

    return(
        <div className='mainContainer'>
            <ToastContainer position="top-right" autoClose={5000} hideProgressBar={false} closeOnClick={true} pauseOnHover={true} draggable={true} />
            <Header numberOfFavorites={favoriteList.length} setDisplayFavorites={setDisplayFavorites} displayFavorites={displayFavorites} searchValue={searchValue} setSearchValue={setSearchValue} allCharacters={allCharacters}/>
            <CharacterCard  favorites={favoriteList} setFavorites={setFavoriteList} searchedResultList={searchedResultList} />
            <div className={`${displayFavorites === true? "forward":"" }`}> <Favorites displayFavorites={displayFavorites} setDisplayFavorites={setDisplayFavorites} favoriteList={favoriteList} deleteFromFavoriteList={deleteFromFavoriteList}/> </div>
        </div>
    )
}
