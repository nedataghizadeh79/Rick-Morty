import './CharacterCard.css'
import { useState} from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye } from '@fortawesome/free-regular-svg-icons';
import Info from "../Info/Info";

export default function CharacterCard({favorites, setFavorites, searchedResultList}){

    const [selectedCharacter, setSelectedCharacter] = useState({
        "name":"",
        "status":"",
        "image":"",
        "id":"",
        "location": "",
        "gender": "",
        "addedToFavorite":""
    })

    function handleClick(name , status, image, id, location, gender){
        setSelectedCharacter({
            name: name,
            status: status,
            image: image,
            id: id,
            location: location,
            gender: gender,
        })
    }


    function handleAddFavorite(selectedCharacter){
        const exist = favorites.find((character)=>character.id===selectedCharacter.id)
        if(!exist){
            setFavorites((prevState)=>[...prevState, selectedCharacter])
        }
        console.log(favorites)
    }


    function isEmptyObj(obj) {
        return Object.keys(obj).every(key=>obj[key]==="")
    }

    return(
        <div className='containerCharacterCard'>
                <div className="leftSide">
                    {searchedResultList.map((character)=>{
                        return(
                            <div key={character.id} className="showData"  onClick={()=>handleClick(character.name, character.status, character.image, character.id, character.location, character.gender)} >
                                <img className='characterImg' src={character.image}  alt='{}' />
                                <div className='info'>
                                    <Info gender={character.gender} name={character.name} status={character.status} />
                                </div>
                                <div >
                                    <FontAwesomeIcon icon={faEye} style={{ fontSize: '2.2rem', color: '#9f2913' }}  />
                                </div>
                            </div>
                        )
                    })}
                </div>
            {
                (!isEmptyObj(selectedCharacter)) &&(
                    <div className="rightSide">
                        <img className='bigPic' src={selectedCharacter.image} alt="" />
                        <div className='columnSide'>
                            <Info gender={selectedCharacter.gender} name={selectedCharacter.name} status={selectedCharacter.status}/>
                            <div className="columnSide">
                                <p style={{color:"#e77c7c"}}> Last  Known  Locations:</p>
                                <h4 className='loc'> {selectedCharacter.location.name} </h4>
                            </div>
                            <button onClick={()=>handleAddFavorite(selectedCharacter)} className='favoriteBtn'> Add to favorite</button>
                        </div>
                    </div>
                )
            }
        </div>
    )
}
