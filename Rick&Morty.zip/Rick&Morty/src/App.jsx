import Main from "./components/Main/Main";
import {FavoriteListContextProvider} from "./context/FavoriteListContext";
function App() {
    return (
        <FavoriteListContextProvider>
            <div className='app'>
                <Main/>
            </div>
        </FavoriteListContextProvider>
    );
}
export default App;
